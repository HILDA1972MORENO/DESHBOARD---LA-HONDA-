
import streamlit as st
import pandas as pd
import plotly.express as px

st.set_page_config(page_title="Dashboard Microcuenca La Honda", layout="wide")

st.title("Sistema Automatizado de Análisis Geoespacial")
st.subheader("Microcuenca Quebrada La Honda")
st.markdown("""
**Autor:** María Hilda Moreno Martínez  
**Programa:** Maestría en Ordenación de Cuencas Hidrográficas – CATIE
""")

st.sidebar.header("Navegación")
op = st.sidebar.radio("Módulo",[
"Inicio","DEM","Pendientes","Temperatura","Precipitación","Estadísticas"
])

c1,c2,c3,c4 = st.columns(4)
c1.metric("Estado GEE","🟢 Activo")
c2.metric("Área","-- ha")
c3.metric("Elevación media","-- m")
c4.metric("Pendiente media","-- %")

if op=="Inicio":
    st.write("Este dashboard está diseñado para integrarse con el notebook de Google Colab y Google Earth Engine.")
    st.info("Reemplace los valores '--' con los resultados calculados por el notebook.")
elif op=="DEM":
    st.header("Modelo Digital de Elevación")
    st.write("Espacio para mapa interactivo (geemap/Folium).")
elif op=="Pendientes":
    st.header("Distribución de pendientes")
    df=pd.DataFrame({"Clase":["Plano","Suave","Moderado","Fuerte"],"Área":[10,25,40,25]})
    st.plotly_chart(px.bar(df,x="Clase",y="Área"),use_container_width=True)
elif op=="Temperatura":
    df=pd.DataFrame({"Mes":list(range(1,13)),"Temp":[20,20.2,20.5,20.8,21,20.7,20.6,20.4,20.3,20.1,20,19.9]})
    st.plotly_chart(px.line(df,x="Mes",y="Temp"),use_container_width=True)
elif op=="Precipitación":
    df=pd.DataFrame({"Mes":list(range(1,13)),"P(mm)":[80,90,120,180,210,160,110,95,140,180,150,100]})
    st.plotly_chart(px.line(df,x="Mes",y="P(mm)"),use_container_width=True)
else:
    st.header("Estadísticas")
    st.dataframe(pd.DataFrame({
        "Variable":["Área","Elevación","Pendiente","Temperatura","Precipitación"],
        "Valor":["--","--","--","--","--"]
    }),use_container_width=True)
