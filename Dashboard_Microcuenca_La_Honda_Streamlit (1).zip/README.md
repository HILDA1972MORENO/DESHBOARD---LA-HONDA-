
# Dashboard Microcuenca Quebrada La Honda

## Ejecutar
pip install -r requirements.txt
streamlit run dashboard.py

## Integración
- Conectar las salidas del notebook de Google Colab.
- Leer GeoTIFF, CSV o resultados exportados desde Google Earth Engine.
- Sustituir los KPIs y gráficos de ejemplo por los datos reales.
